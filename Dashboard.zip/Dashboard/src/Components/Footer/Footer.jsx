import React from 'react'

const Footer = ({currentColor}) => {
  return (
    <footer className='flex justify-between items-center py-5 border-t-1'>
        <div className={currentColor=='black' ? "text-white" : ""}>Thank you for creating with Phoenix React | 2025 @ AstuteInfoSolution</div>
        <div className={currentColor == 'black' ? 'text-white' : ""}>v1.6.0</div>
    </footer>
  )
}

export default Footer