export const LatestReviewsData = [
  {
    id: 1,
    pImg: "https://media-ik.croma.com/prod/https://media.croma.com/image/upload/v1675176879/Croma%20Assets/Communication/Wearable%20Devices/Images/233718_6_cxhfmk.png?tr=w-360",
    pName : "fitbit Sense Smartwatch with Bluetooth Calling (40mm AMOLED Display, 50 Meter Water Resistant, Carbon Strap)",
    pPic: "R",
    sName: "richard dawkins",
    rating: 5,
    review:
      "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.",
    status: "approved",
  },
  {
    id: 2,
    pImg: "https://media-ik.croma.com/prod/https://media.croma.com/image/upload/v1725959769/Croma%20Assets/Communication/Mobiles/Images/309731_0_arlcvj.png?tr=w-360",
    pName : "Apple iPhone 16 Pro (256GB, Natural Titanium)",
    pPic: "A",
    sName: "ashley garett",
    rating: 3,
    review:
      "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.",
    status: "approved",
  },
  {
    id: 3,
    pImg: "https://media-ik.croma.com/prod/https://media.croma.com/image/upload/v1685966374/Croma%20Assets/Computers%20Peripherals/Laptop/Images/256711_umnwok.png?tr=w-360",
    pName: "Apple MacBook Air 2020 (M1, 13.3 Inch, 8GB, 256GB, macOS Big Sur, Space Grey",
    pPic: "W",
    sName: "woodrow burton",
    rating: 4.5,
    review:
      "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.",
    status: "pending",
  },
  {
    id: 4,
    pImg: "https://media-ik.croma.com/prod/https://media.croma.com/image/upload/v1683209850/Croma%20Assets/Computers%20Peripherals/Monitor/Images/250017_0_ziqtik.png?tr=w-360",
    pName: "Apple iMac 24 Inch 4.5K Retina Display 2021 (M1 Chip, 8GB, 256GB, Apple, macOS Big Sur, Blue",
    pPic: "E",
    sName: "eric McGee",
    rating: 3,
    review:
      "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.",
    status: "pending",
  },
  {
    id: 5,
    pImg: "https://media-ik.croma.com/prod/https://media.croma.com/image/upload/v1682595721/Croma%20Assets/Entertainment/Headphones%20and%20Earphones/Images/240928_0_hnncfa.png?tr=w-360",
    pName: "RAZER Kraken RZ04-02830100-R3M1 Wired Gaming Headset (Clear & Powerful Sound, Over Ear, Black)",
    pPic: "K",
    sName: "kim carroll",
    rating: 4,
    review:
      "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.",
    status: "pending",
  },
  {
    id: 6,
    pImg: "https://media-ik.croma.com/prod/https://media.croma.com/image/upload/v1697019995/Croma%20Assets/Gaming/Gaming%20Consoles/Images/231645_0_gkp2tg.png?tr=w-360",
    pName: "SONY DualSense Wireless Controller for Playstation 5 (Highly Immersive Gaming Experience, CFI-ZCT1WRU, White)",
    pPic: "B",
    sName: "barbara lucas",
    rating: 4,
    review:
      "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.",
    status: "approved",
  },
];
