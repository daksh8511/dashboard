import React from "react";
import { IoMdSearch } from "react-icons/io";

import { FaSort } from "react-icons/fa";

import { LatestReviewsData } from "./LatetsReviewsData";
import { FaStar } from "react-icons/fa6";

import { MdNavigateNext, MdNavigateBefore } from "react-icons/md";
import BottomButton from "../BottomButton/BottomButton";

const LatestReviews = ({ currentColor }) => {
  const colors = {
    orange: "#F2C265",
    grey: "a9a9a9",
  };

  const stars = [1, 2, 3, 4, 5];

  return (
    <div
      className={
        currentColor == "black" ? "mt-12 bg-black p-5" : "mt-12 bg-white p-5"
      }
    >
      <div className="latestreview_header flex justify-between items-center">
        <div className="left_side">
          <h2
            className={
              currentColor == "black" ? "font-bold text-white" : "font-bold"
            }
          >
            Latest Review
          </h2>
          <p className={currentColor == "black" ? "text-white" : ""}>
            Payment received across all channels
          </p>
        </div>
        <div className="right_side flex items-center justify-between gap-10">
          <div className="searchbox rounded flex items-center p-3 gap-3 border border-[#8e8e8e]">
            <IoMdSearch
              className={currentColor == "black" ? "text-white" : ""}
            />
            <input
              type="text"
              className={
                currentColor == "black"
                  ? "border-0 outline-0 text-white placeholder:text-white"
                  : "border-0 outline-0"
              }
              placeholder="Search..."
            />
          </div>
          <div
            className={
              currentColor == "black"
                ? "border border-[#8e8e8e] p-3 rounded cursor-pointer text-white"
                : "border border-[#8e8e8e] p-3 rounded cursor-pointer"
            }
          >
            All Products
          </div>
          <div
            className={
              currentColor == "black"
                ? "border border-[#8e8e8e] p-3 rounded cursor-pointer text-white"
                : "border border-[#8e8e8e] p-3 rounded cursor-pointer"
            }
          >
            ...
          </div>
        </div>
      </div>

      <div className="pcrrs flex items-center py-5 border-y-1 border-[#8e8e8e8e] mt-4">
        <div className="select_all_header mr-3">
          <input type="checkbox" />
        </div>
        <div className="product_title_header flex items-center w-[30%] gap-1">
          <h4
            className={
              currentColor == "black"
                ? "uppercase font-semibold text-sm text-white"
                : "uppercase font-semibold text-sm"
            }
          >
            products
          </h4>
          <FaSort className={currentColor == "black" ? "text-white" : ""} />
        </div>
        <div className="cutomer_title_header flex items-center w-[20%] gap-1">
          <h4
            className={
              currentColor == "black"
                ? "uppercase font-semibold text-sm text-white"
                : "uppercase font-semibold text-sm"
            }
          >
            customer
          </h4>
          <FaSort className={currentColor == "black" ? "text-white" : ""} />
        </div>
        <div className="rating_title_header flex items-center w-[10%] gap-1">
          <h4
            className={
              currentColor == "black"
                ? "uppercase font-semibold text-sm text-white"
                : "uppercase font-semibold text-sm"
            }
          >
            rating
          </h4>
          <FaSort className={currentColor == "black" ? "text-white" : ""} />
        </div>
        <div className="review_title_header flex items-center w-[30%] gap-1">
          <h4
            className={
              currentColor == "black"
                ? "uppercase font-semibold text-sm text-white"
                : "uppercase font-semibold text-sm"
            }
          >
            review
          </h4>
          <FaSort className={currentColor == "black" ? "text-white" : ""} />
        </div>
        <div className="status_title_header flex items-center w-[10%] gap-1">
          <h4
            className={
              currentColor == "black"
                ? "uppercase font-semibold text-sm text-white"
                : "uppercase font-semibold text-sm"
            }
          >
            status
          </h4>
          <FaSort className={currentColor == "black" ? "text-white" : ""} />
        </div>
      </div>

      <div className="box">
        {LatestReviewsData.map((data, i) => {
          return (
            <div
              className="mini_box flex items-center border-b-1 border-[#eee] py-4"
              key={i}
            >
              <div className="sort_box mr-3">
                <input type="checkbox" />
              </div>
              <div className="product_box w-[30%] gap-2 pr-3 flex justify-between items-center">
                <img
                  src={data.pImg}
                  className="w-16 border border-[#ccc] rounded p-3"
                  alt=""
                />
                <h4 className="text-[var(--mytext-blue)] font-semibold truncate text-sm">
                  {data.pName}
                </h4>
              </div>
              <div className="customer_box w-[20%] flex items-center gap-5">
                <span className="bg-gray-400 text-white px-4 py-2 rounded-full">
                  {data.pPic}
                </span>
                <h4 className={currentColor == 'black' ? "font-semibold text-sm capitalize text-white" : "font-semibold text-sm capitalize"}>
                  {data.sName}
                </h4>
              </div>
              <div className="rating_box text-center w-[10%] flex">
                {stars.map((star, index) => {
                  return (
                    <FaStar
                      className="w-[14px]"
                      key={index}
                      // size={24}
                      color={data.rating > index ? colors.orange : colors.grey}
                    />
                  );
                })}
              </div>
              <div className="review_box w-[30%] gap-1">
                <p className={currentColor == 'black' ? "pe-4 text-white" : "pe-4"}>{data.review}</p>
              </div>
              <div className="status_box w-[10%]">
                {data.status == "approved" ? (
                  <span className="uppercase text-sm bg-[#d9fbd0] text-[#25b003] font-bold px-4 rounded py-2">
                    {data.status}
                  </span>
                ) : (
                  <span className="uppercase text-sm bg-[#ffefca] text-[#d26c2b] font-bold px-4 rounded py-2 ">
                    {data.status}
                  </span>
                )}
              </div>
            </div>
          );
        })}
        <div className="viewall_next mt-5">
          <BottomButton currentColor={currentColor} />
        </div>
      </div>
    </div>
  );
};

export default LatestReviews;
