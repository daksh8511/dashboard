import React from "react";

const Dashboard_Mini_Box = ({
  title,
  mini_title,
  number,
  loss_number,
  currentColor,
}) => {
  return (
    <div className="flex justify-between">
      {currentColor == "black" ? (
        <div className="title">
          <div className="dashboardTitle_loss flex items-center">
            <h4 className="font-bold me-3 text-white">{title}</h4>
            <span className="text-[12px] bg-[#ffdfad] text-[#bc3803] font-semibold px-1 rounded-full">
              {loss_number}
            </span>
          </div>
          <p className="text-white">{mini_title}</p>
        </div>
      ) : (
        <div className="title">
          <div className="dashboardTitle_loss flex items-center">
            <h4 className="font-bold me-3">{title}</h4>
            <span className="text-[12px] bg-[#ffdfad] text-[#bc3803] font-semibold px-1 rounded-full">
              {loss_number}
            </span>
          </div>
          <p>{mini_title}</p>
        </div>
      )}

      <h3
        className={
          currentColor == "black"
            ? "font-bold text-xl text-white"
            : "font-bold text-xl"
        }
      >
        {number}
      </h3>
    </div>
  );
};

export default Dashboard_Mini_Box;
