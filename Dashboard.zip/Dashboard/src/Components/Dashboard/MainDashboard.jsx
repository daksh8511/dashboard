import React from "react";
import "../../AssetsVariables.scss";

import "./MainDashboard.scss";

import { FaStar, FaPause } from "react-icons/fa";

import { IoClose } from "react-icons/io5";

import star from "/assets/star.png";
import pause from "/assets/pause.png";
import close from "/assets/close.png";
import Dashboard_Mini_Box from "../Dashboard_Mini_Box/Dashboard_Mini_Box";
import BarChart from "../ChartBox/BarChart/BarChart";
import LineChart from "../ChartBox/LineChart/LineChart";
import DoughnutChart from "../ChartBox/DoughnutChart/DoughnutChart";
import HalfDoughnutChart from "../ChartBox/HalfDoughnutChart/HalfDoughnutChart";
import BigLineChart from "../ChartBox/LineChart/BigLineChart/BigLineChart";
import LatestReviews from "../LatestReviews/LatestReviews";
import RegionByRevenue from "../RegionByRevenue/RegionByRevenue";
import DoubleBar from "../ChartBox/DoubleBar/DoubleBar";
import ReturnCustomerRate from "../ChartBox/ReturnCustomerRate/ReturnCustomerRate";
import Footer from "../Footer/Footer";

const MainDashboard = ({ currentColor }) => {
  return (
    <div
      className={
        currentColor == "black"
          ? "maindashboard p-5 !bg-black relative w-[93.3vw] left-[75px] top-[64px] z-0"
          : "maindashboard p-5 relative w-[93.3vw] left-[75px] top-[64px] z-0"
      }
    >
      <div className="banner_title flex justify-between pb-2">
        {currentColor == "black" ? (
          <div className="title">
            <h2 className="font-bold text-white">Ecommerce Dashboard</h2>
            <p className="capitalize font-semibold text-white">
              here's what's going on at your business right now
            </p>
          </div>
        ) : (
          <div className="title">
            <h2 className="font-bold">Ecommerce Dashboard</h2>
            <p className="capitalize font-semibold text-gray-500">
              here's what's going on at your business right now
            </p>
          </div>
        )}

        <div className="flex items-center gap-10 h-[55px]">
          {currentColor == "black" ? (
            <div className="box flex items-center">
              <div className="icon_box">
                <FaStar className="text-white" />
              </div>
              <div className="text_box ms-5">
                <h3 className="font-bold text-[17px] text-white">
                  57 New Orders
                </h3>
                <p className="text-[13px] text-white">Awaiting processing</p>
              </div>
            </div>
          ) : (
            <div className="box flex items-center">
              <div className="icon_box">
                <FaStar className="text-[#25b003]" />
              </div>
              <div className="text_box ms-5">
                <h3 className="font-bold text-[17px]">57 New Orders</h3>
                <p className="text-[13px]">Awaiting processing</p>
              </div>
            </div>
          )}

          {currentColor == "black" ? (
            <div className="box flex items-center">
              <div className="icon_box">
                <FaPause className="text-white" />
              </div>
              <div className="text_box ms-5">
                <h3 className="font-bold text-[17px] text-white">5 Orders</h3>
                <p className="text-[13px] text-white">On hold</p>
              </div>
            </div>
          ) : (
            <div className="box flex items-center">
              <div className="icon_box">
                <FaPause className="text-[#e5780b]" />
              </div>
              <div className="text_box ms-5">
                <h3 className="font-bold text-[17px]">5 Orders</h3>
                <p className="text-[13px]">On hold</p>
              </div>
            </div>
          )}

          {currentColor == "black" ? (
            <div className="box flex items-center">
              <div className="icon_box">
                <IoClose className="text-2xl text-white" />
              </div>
              <div className="text_box ms-5">
                <h3 className="font-bold text-[17px] text-white">15 Products</h3>
                <p className="text-[13px] text-white">Out of stock</p>
              </div>
            </div>
          ) : (
            <div className="box flex items-center">
              <div className="icon_box">
                <IoClose className="text-2xl text-[#ee381d]" />
              </div>
              <div className="text_box ms-5">
                <h3 className="font-bold text-[17px]">15 Products</h3>
                <p className="text-[13px]">Out of stock</p>
              </div>
            </div>
          )}
        </div>
      </div>
      <div className="banner_dashboard pt-5 grid grid-cols-2">
        {/* first left box start */}
        <div className={currentColor == "black" ? "first_left_box me-3 bg-black p-3" : "first_left_box me-3 bg-white p-3"}>
          <div className="left_box mb-3">
            <Dashboard_Mini_Box
              title={"Total Orders"}
              loss_number={"-6.8%"}
              mini_title={"Last 7 Days"}
              number={"16,247"}
              currentColor={currentColor}
            />
          </div>
          <div className="right_box">
            <BarChart currentColor={currentColor} />
          </div>
        </div>
        {/* first right box start */}
        <div className={currentColor == "black" ? "first_left_box me-3 bg-black p-3" : "first_left_box me-3 bg-white p-3"}>
          <div className="left_box mb-3">
            <Dashboard_Mini_Box
              title={"New Customers"}
              loss_number={"+26.5%"}
              mini_title={"Last 7 Days"}
              number={"356"}
              currentColor={currentColor}
            />
          </div>
          <div className="right_box">
            <LineChart currentColor={currentColor} />
          </div>
        </div>
        {/* second left box start */}
        <div className={currentColor == "black" ? "sec_left_box bg-black me-3 mt-4 p-3" : "sec_left_box bg-white me-3 mt-4 p-3"}>
          <div className="left_box mb-3">
            <Dashboard_Mini_Box
              title={"Top Coupons"}
              mini_title={"Last 7 Days"}
              currentColor={currentColor}
            />
          </div>
          <div className="right_box">
            <DoughnutChart currentColor={currentColor} />
          </div>
        </div>
        {/* second right box start */}
        <div className={currentColor == "black" ? "sec_right_box bg-black p-3 mt-4" : "sec_right_box bg-white p-3 mt-4"}>
          <div className="left_box mb-3">
            <Dashboard_Mini_Box
              title={"Playing vs non playing"}
              mini_title={"Last 7 Days"}
              currentColor={currentColor}
            />
          </div>
          <div className="right_box">
            <HalfDoughnutChart currentColor={currentColor} />
          </div>
        </div>
      </div>
      <BigLineChart currentColor={currentColor} />
      <LatestReviews currentColor={currentColor} />
      <RegionByRevenue currentColor={currentColor} />
      <div className={currentColor == 'black' ? "grid grid-cols-2 bg-black p-5" : "grid grid-cols-2 bg-white p-5"}>
        <DoubleBar currentColor={currentColor} />
        <ReturnCustomerRate currentColor={currentColor} />
      </div>
      <Footer currentColor={currentColor} />
    </div>
  );
};

export default MainDashboard;
