import React, { useState } from "react";
import Header from "../Header/Header";
import SideMenu from "../SideMenu/SideMenu";
import MainDashboard from "./MainDashboard";

const Dashboard = () => {
  const [bgColor, setBgColor] = useState("white")

  const changeColor = () => {
    if(bgColor == "black"){
      setBgColor("white")
    }
    else{
      setBgColor("black")
    }
  }
  return (
    <div className="dashboard">
      <Header currentColor={bgColor} changeColor={changeColor} setBgColor={setBgColor} />

      <div className="flex">
        <SideMenu />
        <MainDashboard currentColor={bgColor} />
      </div>

    </div>
  );
};

export default Dashboard;
