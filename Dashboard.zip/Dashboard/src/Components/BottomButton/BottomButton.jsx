import React from "react";

import { MdNavigateNext, MdNavigateBefore } from "react-icons/md";

const BottomButton = ({currentColor}) => {
  return (
    <div className="flex justify-between items-center">
      <div className="viewall flex gap-5 items-center">
        <h4 className={currentColor == "black" ? "text-sm font-semibold text-white" : "text-sm font-semibold"}>1 to 6 items of 15</h4>
        <a
          href=""
          className="flex items-center text-[var(--mytext-blue)] font-bold"
        >
          View all <MdNavigateNext />
        </a>
      </div>
      <div className="prev_next flex items-center gap-7">
        <button className="flex items-center text-[#8a8a8a] cursor-pointer">
          <MdNavigateBefore /> Previous
        </button>
        <button className="flex items-center text-[var(--mytext-blue)] font-semibold cursor-pointer">
          Next <MdNavigateNext />
        </button>
      </div>
    </div>
  );
};

export default BottomButton;
