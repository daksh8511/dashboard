import { Box, TextField } from "@mui/material";
import React, { useRef } from "react";

const SignUp = () => {
  const name = useRef('');

  const handleSignUp = (e) => {
    e.preventDefault();
  };

  return (
    <div className="h-screen">
      <Box>
        <TextField placeholder="Enter Name" label="Name" variant="standard" />
      </Box>
    </div>
  );
};

export default SignUp;
