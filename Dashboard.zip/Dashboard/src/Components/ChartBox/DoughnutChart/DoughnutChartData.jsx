export const DoughnutData = {
  labels: ["red", "green", "blue"],
  datasets: [
    {
      data: [70, 20, 10],
      backgroundColor: [
        "rgb(255, 99, 132)",
        "rgb(54, 162, 235)",
        "rgb(255, 205, 86)",
      ],
      hoverOffset: 4
    },
  ],
};
