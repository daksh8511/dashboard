import React from "react";
import { Chart as DoughnutChartJs, Tooltip, Title, ArcElement } from "chart.js";
import { DoughnutData } from "./DoughnutChartData";
import { Doughnut } from "react-chartjs-2";
import DoughnutText from "../DoughnutText/DoughnutText";

DoughnutChartJs.register(ArcElement, Tooltip, Title);

const DoughnutChart = ({currentColor}) => {
  const options = {};
  return (
    <div>
      <div className="flex justify-center mb-5">
        <Doughnut className="!h-52 " options={{
          plugins:{
            legend:false
          }
        }} data={DoughnutData} />
      </div>
      <DoughnutText currentColor={currentColor} box_text={"Percentage Discount"} percentage={"72%"} />
      <DoughnutText currentColor={currentColor} box_text={"Fixed Card Discount"} percentage={"18%"} />
      <DoughnutText currentColor={currentColor} box_text={"Fixed Product Discount"} percentage={"10%"} />
    </div>
  );
};

export default DoughnutChart;
