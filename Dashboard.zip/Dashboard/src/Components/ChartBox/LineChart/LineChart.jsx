import React from "react";

import {
  Chart as LineChartJs,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Tooltip,
  Title,
} from "chart.js";

import { Line } from "react-chartjs-2";
import { LineData } from "./LineData";

LineChartJs.register(CategoryScale, LinearScale, PointElement, LineElement, Tooltip, Title);

const LineChart = ({currentColor}) => {
  return (
    <div>
      {
        currentColor == "black" ? 
        <Line options={{
          plugins:{
            legend: false
          },
          borderColor : 'white',
          scales:{
            y:{
              ticks:{
                display: false
              },
              grid : {
                color : "white",
              },
            },
            x : {
              grid : {
                color : "white"
              },
            }
          }
        }} data={LineData} /> :
        <Line options={{
          plugins:{
            legend: false,
          },
          borderColor : "#3874ff",
          scales:{
            y:{
              ticks:{
                display: false,
              },
            }
          }
        }} data={LineData} />
      }
    </div>
  )
};

export default LineChart;
