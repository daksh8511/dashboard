export const LineData = {
  labels: ["1 May", "2 May", "3 May", "4 May", "5 May", "6 May", "7 May"],
  datasets: [
    {
      data: [1, 3, 2, 7, 2, 4, 7],
      backgroundColor: "#3874ff",
    },
  ],
};
