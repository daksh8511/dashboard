import React from "react";

import "./BigLineCss.css";

import {
  Chart as BigChart,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Tooltip,
  Title,
  plugins,
} from "chart.js";

BigChart.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Tooltip,
  Title
);

import { Line } from "react-chartjs-2";
import { BigData } from "./BigLineData";

const BigLineChart = ({ currentColor }) => {
  return (
    <div className="mt-10 bigLineChart">
      <div className="title flex justify-between items-center mb-5">
        <div className="left_title">
          <h3 className={currentColor == "black" ? "mb-1 font-bold text-3xl text-white" : "mb-1 font-bold text-3xl text-black"}>Total Sells</h3>
          <span className={currentColor == 'black' ? "text-white" : ""}>Payment received across all channel</span>
        </div>
        <div className="right_title">
          <select id="menu" className="bg-white outline-0 text-[#8a8a8a] p-3">
            <option value="May 1 - 31, 2023">May 1 - 31, 2023</option>
            <option value="May 1 - 31, 2023">June 1 - 30, 2023</option>
            <option value="May 1 - 31, 2023">July 1 - 31, 2023</option>
            <option value="May 1 - 31, 2023">August 1 - 30, 2023</option>
          </select>
        </div>
      </div>
      <Line
        options={{
          maintainAspectRatio: false,
          responsive: true,
          plugins: {
            legend: false,
          },
          scales: {
            y: {
              max: 7000,
              min: 0,
              ticks: {
                display: false,
              },
              grid: {
                color: "gray",
              },
            },
            x: {
              grid: {
                color: "gray",
              },
            },
          },
        }}
        data={BigData}
      />
    </div>
  );
};

export default BigLineChart;
