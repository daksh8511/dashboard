export const BigData = {
  labels: ["1 May", "5 May", "10 May", "15 May", "20 May", "25 May", "30 May"],
  datasets: [
    {
      data: [2400, 1000, 4000, 3000, 2700, 4300, 6000],
      borderColor: "blue",
    },
    {
      data: [2200, 5000, 1000, 4000, 1400, 3200, 2000],
      borderColor: "#FF6384",
      borderDash: [5,4]
    },
  ],
};
