export const HalfDoughnutData = {
  datasets: [
    {
      data: [70, 30],
      backgroundColor: ["rgb(255, 99, 132)", "rgb(54, 162, 235)"],
    },
  ],
};
