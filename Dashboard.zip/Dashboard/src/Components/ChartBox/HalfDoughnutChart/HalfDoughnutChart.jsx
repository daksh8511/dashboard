import React from "react";

import { Chart as HalfDoughnutChartJs, ArcElement, Tooltip } from "chart.js";
import { Doughnut } from "react-chartjs-2";
import { HalfDoughnutData } from "./HalfDoughnutData";
import DoughnutText from "../DoughnutText/DoughnutText";

HalfDoughnutChartJs.register(ArcElement, Tooltip);

const HalfDoughnutChart = ({currentColor}) => {
  const options = {};
  return (
    <div>
      <div className="chart flex justify-center">
        <Doughnut
          options={{
            rotation: -90,
            cutout: "60%",
            circumference: 180,
          }}
          data={HalfDoughnutData}
          className="!h-52"
        />
      </div>
      <div className="chart_text mt-12">
        <DoughnutText currentColor={currentColor} box_text={"Paying Customers"} percentage={"70%"} />
        <DoughnutText currentColor={currentColor} box_text={"Non-Paying Customers"} percentage={"30%"} />
      </div>
    </div>
  );
};

export default HalfDoughnutChart;
