export const ReturnData = {
  labels: [
    "Feb",
    "Mar",
    "Apr",
    "May",
    "Jun",
    "Jul",
    "Aug",
    "Sep",
    "Oct",
    "Nov",
  ],
  datasets: [
    {
      label: "Fourth Time",
      data: [20, 10, 40, 50, 35, 60, 78, 20, 42, 10],
      borderColor : "rgb(255, 99, 132)",
    },
    {
      label: "Third Time",
      data: [50, 20, 20, 10, 59, 70, 29, 50, 90, 40],
      borderColor : "rgb(54, 162, 235)",
    },
    {
      label: "Second Time",
      data: [70, 30, 60, 70, 95, 80, 58, 40, 49, 89],
      borderColor : "rgb(255, 205, 86)",
    },
  ],
};
