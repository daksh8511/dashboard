import React from "react";

import {
  Chart as LineChartReturn,
  CategoryScale,
  LinearScale,
  LineElement,
  Tooltip,
  Title,
} from "chart.js";
import { Line } from "react-chartjs-2";
import { ReturnData } from "./ReturnCustomerData";

LineChartReturn.register(
  CategoryScale,
  LinearScale,
  LineElement,
  Tooltip,
  Title
);

const ReturnCustomerRate = ({ currentColor }) => {
  const options = {};
  return (
    <div className="py-7 ps-5">
      <div className="title">
        <h2
          className={
            currentColor == "black" ? "font-bold text-white" : "font-bold"
          }
        >
          Returning customer rate
        </h2>
        <p
          className={
            currentColor == "black" ? "font-bold text-white" : "font-bold"
          }
        >
          Rate of customers returning to your shop over time
        </p>
      </div>
      {currentColor == "black" ? (
        <Line
          options={{
            scales: {
              y: {
                max: 100,
                min: 0,
                ticks: {
                  stepSize: 20,
                },
                grid: {
                  color: "white",
                },
              },
              x : {
                grid :{
                  color : 'white'
                }
              }
            },
          }}
          data={ReturnData}
        />
      ) : (
        <Line
          options={{
            scales: {
              y: {
                max: 100,
                min: 0,
                ticks: {
                  stepSize: 20,
                },
              },
            },
          }}
          data={ReturnData}
        />
      )}
    </div>
  );
};

export default ReturnCustomerRate;
