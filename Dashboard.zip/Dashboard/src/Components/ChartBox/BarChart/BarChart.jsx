import React from "react";
import "./BarChart.css";

import {
  Chart as BarChartJs,
  CategoryScale,
  LinearScale,
  BarElement,
  LineElement,
  Tooltip,
  Title,
} from "chart.js";

import { BarData } from "./BarData";

BarChartJs.register(
  CategoryScale,
  LinearScale,
  BarElement,
  LineElement,
  Tooltip,
  Title
);

import { Bar } from "react-chartjs-2";

const BarChart = ({currentColor}) => {
  return (
    <div className="barChart">
      {
        currentColor=="black" ?
<Bar
          options={{
            plugins: {
              legend: false,
            },
            scales: {
              y: {
                ticks: {
                  display: false,
                },
                grid: {
                  color : 'white'
                }
              },
              x: {
                grid : {
                  color : "white"
                }
              }
            },
          }}
          data={BarData}
        />:
        <Bar
          options={{
            plugins: {
              legend: false,
            },
            scales: {
              y: {
                ticks: {
                  display: false,
                },
              },
            },
          }}
          data={BarData}
        />
      }
        
    </div>
  );
};

export default BarChart;
