export const BarData = {
  labels: ["", "", "", "", "", "", ""],
  datasets: [
    {
      data: [1, 5, 7, 1, 3, 4, 2],
      backgroundColor: "#3874ff",
      barPercentage: 0.5,
      borderRadius: Number.MAX_VALUE,
    },
  ],
};
