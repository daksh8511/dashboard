export const DoubleBarData = {
  labels: ["Jan 18", "Jan 19", "Jan 20", "Jan 21", "Jan 22"],
  datasets: [
    {
      label: "Projectded Revenue",
      data: ["30000", "20000", "30000", "40000", "40000"],
      backgroundColor: "#3874ff",
      barPercentage: 0.5,
      borderRadius: 15,
      categoryPercentage: 0.2,
      barPercentage: 1.0,
    },
    {
      label: "Actual Revenue",
      data: ["20000", "25000", "40000", "45000", "30000"],
      backgroundColor: "#FF6384",
      barPercentage: 0.5,
      borderRadius: 15,
      categoryPercentage: 0.2,
      barPercentage: 1.0,
    },
  ],
};
