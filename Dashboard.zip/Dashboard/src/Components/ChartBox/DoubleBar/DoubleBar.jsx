import React from "react";

import {
  Chart as DoubleBarChartJs,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Tooltip,
  Title,
  Legend,
} from "chart.js";

DoubleBarChartJs.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Tooltip,
  Title,
  Legend
);

import { Bar } from "react-chartjs-2";
import { DoubleBarData } from "./DoubleBarData";

const DoubleBar = ({currentColor}) => {
  return (
    <div className="py-7">
      <div className="title">
        <h2 className={currentColor == 'black' ? "font-bold text-white" : "font-bold"}>Projection vs Actual</h2>
        <p className={currentColor == 'black' ? "font-bold text-white" : "font-bold"}>Actual earning vs projected earnings</p>
      </div>

      {
        currentColor == 'black' ?
        <Bar
        options={{
          scales: {
            y: {
              max: 50000,
              min: 10000,
              ticks : {
                stepSize : 10000
              },
              grid: {
                color: 'white'
              },
            },
            x : {
              grid : {
                color : "white"
              }
            }
          }
        }}
        data={DoubleBarData}
      />
        :
        <Bar
        options={{
          scales: {
            y: {
              max: 50000,
              min: 10000,
              ticks : {
                stepSize : 10000
              },
            },
          }
        }}
        data={DoubleBarData}
      />
      }
      
    </div>
  );
};

export default DoubleBar;
