import React from "react";

const DoughnutText = ({ box_text, percentage, currentColor }) => {
  return (
    <div className="flex justify-between items-center mb-2">
      {currentColor == "black" ? (
        <div className="left_side">
          <h5 className="text-sm font-semibold text-white">{box_text}</h5>
        </div>
      ) : (
        <div className="left_side">
          <h5 className="text-sm font-semibold">{box_text}</h5>
        </div>
      )}

      {currentColor == "black" ? (
        <div className="left_side">
          <h5 className="text-sm text-white">{percentage}</h5>
        </div>
      ) : (
        <div className="left_side">
          <h5 className="text-sm">{percentage}</h5>
        </div>
      )}
    </div>
  );
};

export default DoughnutText;
