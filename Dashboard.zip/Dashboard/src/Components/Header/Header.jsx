import React, { useRef, useState } from "react";

import logo from "/assets/logo.png";

import { IoSearch } from "react-icons/io5";
import { IoIosSettings } from "react-icons/io";
import { FaSun, FaMoon } from "react-icons/fa";



const Header = ({ currentColor, setBgColor }) => {
  const [myHidden, setHidden] = useState("hidden");

  const blockFunction = () => {
    setHidden("block");
    console.log(currentColor);
    setBgColor("black");
  };

  const hiddenFunction = () => {
    setHidden("hidden");
    console.log(currentColor);
    setBgColor("white");
  };

  return (
    <header
      className={
        currentColor == "black"
          ? "fixed z-10 bg-black w-full border border-b-gray-400 border-x-0 border-t-0 py-4"
          : "fixed z-10 bg-white w-full border border-b-gray-400 border-x-0 border-t-0 py-4"
      }
    >
      <div className="container flex justify-between items-center text-center">
        <div className="logo">
          <img src={logo} className="w-35" alt="" />
        </div>

        {currentColor == "black" ? (
          <div className="search flex items-center gap-3 border border-white rounded-full p-2">
            <IoSearch className="text-white" />
            <input
              className="border-0 outline-0 placeholder:text-white text-white"
              type="text"
              placeholder="Seach..."
            />
          </div>
        ) : (
          <div className="search flex items-center gap-3 border rounded-full p-2">
            <IoSearch />
            <input
              className="border-0 outline-0"
              type="text"
              placeholder="Seach..."
            />
          </div>
        )}
        <div className="mode_setting flex gap-5 items-center">
          <div className="mode flex">
            {myHidden == "hidden" ? (
              <FaMoon
                className="text-2xl cursor-pointer block"
                onClick={blockFunction}
              />
            ) : (
              <FaSun
                className="text-2xl text-white cursor-pointer"
                onClick={hiddenFunction}
              />
            )}
          </div>
          <div className="setting">
            {currentColor == "black" ? (
              <IoIosSettings className="text-3xl text-white cursor-pointer" />
            ) : (
              <IoIosSettings className="text-3xl text-black cursor-pointer" />
            )}
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;
