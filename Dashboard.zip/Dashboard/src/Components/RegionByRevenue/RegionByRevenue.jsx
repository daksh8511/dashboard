import React from "react";

import { FaSort } from "react-icons/fa";
import BottomButton from "../BottomButton/BottomButton";

import { RevenueData } from "./RevenueData";

const RegionByRevenue = ({ currentColor }) => {
  return (
    <div className="py-10">
      <div className="box flex">
        <div className="left_box w-2/4">
          <div className="title mb-5">
            <h2
              className={
                currentColor == "black" ? "font-bold text-white" : "font-bold"
              }
            >
              Top region by revenue
            </h2>
            <p className={currentColor == "black" ? "text-white" : ""}>
              Where you generated most of the revenue
            </p>
          </div>
          <div className="all_title flex border-y-1 border-[#ccc] py-3">
            <div
              className={
                currentColor == "black"
                  ? "coutray uppercase flex items-center gap-1 font-semibold text-sm w-1/5 text-white"
                  : "coutray uppercase flex items-center gap-1 font-semibold text-sm w-1/5"
              }
            >
              country <FaSort />
            </div>
            <div
              className={
                currentColor == "black"
                  ? "users uppercase flex items-center gap-1 font-semibold text-sm w-1/5 text-white"
                  : "users uppercase flex items-center gap-1 font-semibold text-sm w-1/5"
              }
            >
              users <FaSort />
            </div>
            <div
              className={
                currentColor == "black"
                  ? "transaction me-3 uppercase flex items-center gap-1 font-semibold text-sm w-1/5 text-white"
                  : "transaction me-3 uppercase flex items-center gap-1 font-semibold text-sm w-1/5"
              }
            >
              transactions <FaSort />
            </div>
            <div
              className={
                currentColor == "black"
                  ? "revenue uppercase flex items-center gap-1 font-semibold text-sm w-1/5 text-white"
                  : "revenue uppercase flex items-center gap-1 font-semibold text-sm w-1/5"
              }
            >
              revenue <FaSort />
            </div>
            <div
              className={
                currentColor == "black"
                  ? "converion uppercase flex items-center gap-1 font-semibold text-sm w-1/5 text-white"
                  : "converion uppercase flex items-center gap-1 font-semibold text-sm w-1/5"
              }
            >
              con. rate <FaSort />
            </div>
          </div>
          <div className="values flex py-5 border-b-1 border-[#ccc]">
            <div className="first_box w-1/5"></div>
            <div
              className={
                currentColor == "black"
                  ? "sec_box w-1/5 font-semibold text-center text-2xl text-white"
                  : "sec_box w-1/5 font-semibold text-center text-2xl"
              }
            >
              377,620
            </div>
            <div
              className={
                currentColor == "black"
                  ? "third_box w-1/5 font-semibold text-center text-2xl text-white"
                  : "third_box w-1/5 font-semibold text-center text-2xl"
              }
            >
              236
            </div>
            <div
              className={
                currentColor == "black"
                  ? "fourth_box w-1/5 font-semibold text-center text-2xl text-white"
                  : "fourth_box w-1/5 font-semibold text-center text-2xl"
              }
            >
              $15,758
            </div>
            <div
              className={
                currentColor == "black"
                  ? "fiftht_box w-1/5 font-semibold text-center text-2xl text-white"
                  : "fiftht_box w-1/5 font-semibold text-center text-2xl"
              }
            >
              10.32%
            </div>
          </div>
          <div className="datas mb-4">
            {RevenueData.map((data, i) => {
              return (
                <div
                  key={i}
                  className="flex items-center gap-4 border-b-1 border-[#ccc] py-4"
                >
                  <div className="nation flex items-center gap-5 w-1/5">
                    <span className={currentColor == "black" ? "text-sm font-semibold text-white" : "text-sm font-semibold"}>{data.id}.</span>
                    <img className="w-[25px]" src={data.flag} alt="" />
                  </div>
                  <div className="users flex items-center w-1/5 gap-2">
                    <h4 className={currentColor == 'black' ? "font-bold text-[12px] text-white" : "font-bold text-[12px]"}>{data.user}</h4>
                    <span className="text-gray-500 text-[15px]">
                      {data.userByPercentage}
                    </span>
                  </div>
                  <div className="transiction flex items-center w-1/5 gap-2">
                    <h4 className={currentColor == 'black' ? "font-bold text-[12px] text-white" : "font-bold text-[12px]"}>
                      {data.transiction}
                    </h4>
                    <span className="text-gray-500 text-[15px]">
                      {data.transByPercentage}
                    </span>
                  </div>
                  <div className="revenue flex items-center w-1/5 gap-2">
                    <h4 className={currentColor == 'black' ? "font-bold text-[12px] text-white" : "font-bold text-[12px]"}>${data.revenue}</h4>
                    <span className="text-gray-500 text-[15px]">
                      {data.reveByPercentage}
                    </span>
                  </div>
                  <div className="conversion w-1/5">
                    <h4 className={currentColor == 'black' ? "font-bold text-[12px] text-white" : "font-bold text-[12px]"}>
                      {data.conRate}
                    </h4>
                  </div>
                </div>
              );
            })}
          </div>
          <BottomButton currentColor={currentColor} />
        </div>
        <div className="right_side w-2/4">
          <iframe
            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3036.0042568403637!2d-3.6909086254149117!3d40.45304275343068!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0xd4228e23705d39f%3A0xa8fff6d26e2b1988!2sSantiago%20Bernab%C3%A9u%20Stadium!5e0!3m2!1sen!2sin!4v1738329514728!5m2!1sen!2sin"
            width="100%"
            height="100%"
            style={{ border: 0 }}
            allowFullScreen={true}
            loading="lazy"
            referrerPolicy="no-referrer-when-downgrade"
          ></iframe>
        </div>
      </div>
    </div>
  );
};

export default RegionByRevenue;
