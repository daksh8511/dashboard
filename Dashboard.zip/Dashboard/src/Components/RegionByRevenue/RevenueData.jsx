

export const RevenueData = [
    {
        id: 1,
        flag : "https://cdn-icons-png.flaticon.com/512/14009/14009677.png",
        user : "92896",
        userByPercentage : "(41.6%)",
        transiction: "67",
        transByPercentage : "(34.3%)",
        revenue : "7560",
        reveByPercentage : "(36.9%)",
        conRate : "14.01%"
    },
    {
        id: 2,
        flag : "https://cdn-icons-png.flaticon.com/512/5111/5111624.png",
        name : "China",
        user : "50496",
        userByPercentage : "(32.8%)",
        transiction: "54",
        transByPercentage : "(23.8%)",
        revenue : "6532",
        reveByPercentage : "(26.5%)",
        conRate : "23.56%"
    },
    {
        id: 3,
        flag : "https://cdn-icons-png.flaticon.com/512/206/206626.png",
        user : "45679",
        userByPercentage : "(24.3%)",
        transiction: "35",
        transByPercentage : "(19.7%)",
        revenue : "5432",
        reveByPercentage : "(16.9%)",
        conRate : "10.23%"
    },
    {
        id: 4,
        flag : "https://cdn-icons-png.flaticon.com/512/206/206758.png",
        name : "South Korea",
        user : "36453",
        userByPercentage : "(19.7%)",
        transiction: "22",
        transByPercentage : "(9.54%)",
        revenue : "4673",
        reveByPercentage : "(11.6%)",
        conRate : "8.85%"
    },
    {
        id: 5,
        flag : "https://cdn-icons-png.flaticon.com/512/555/555515.png",
        user : "15007",
        userByPercentage : "(11.9%)",
        transiction: "17",
        transByPercentage : "(6.91%)",
        revenue : "2456",
        reveByPercentage : "(10.2%)",
        conRate : "6.01%"
    },
]