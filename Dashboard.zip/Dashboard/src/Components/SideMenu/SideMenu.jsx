import React from "react";
import "./SideMenu.scss";

import {
  FaHome,
  FaShoppingCart,
  FaPhoneAlt,
  FaFileAlt,
  FaShoppingBag,
  FaRocketchat,
  FaShareAlt,
  FaCalendarAlt

} from "react-icons/fa";

import { MdEmail } from "react-icons/md";
import { BsCalendar2EventFill, BsFileBarGraphFill } from "react-icons/bs";


const SideMenu = () => {
  return (
    <div className="sidemenu z-10 w-[70px] p-4 hover:w-[250px] hover:overflow-scroll fixed top-[80px] overflow-hidden h-screen bg-white">
      <div className="homeIcon iconbox hover:bg-blue-500 rounded p-2 flex gap-2 items-center">
        <FaHome className="text-gray-500" />
        <h2 className="text-gray-500 font-semibold text-[14px]">Home</h2>
      </div>
      <div className="apps mt-10">
        <h4 className="uppercase text-[12px] font-bold text-gray-500">apps</h4>

        <div className="ecommerce mt-4 iconbox hover:bg-blue-500 rounded p-2 flex gap-2 items-center">
          <FaShoppingCart className="text-gray-500" />
          <h2 className="text-gray-500 font-semibold text-[14px]">
            E Commerce
          </h2>
        </div>
        <div className="crm mt-4 iconbox hover:bg-blue-500 rounded p-2 flex gap-2 items-center">
          <FaPhoneAlt className="text-gray-500" />
          <h2 className="text-gray-500 font-semibold text-[14px]">
            CRM
          </h2>
        </div>
        <div className="pro_man mt-4 iconbox hover:bg-blue-500 rounded p-2 flex gap-2 items-center">
          <FaFileAlt className="text-gray-500" />
          <h2 className="text-gray-500 font-semibold text-[14px]">
            Project Managment
          </h2>
        </div>
        <div className="pro_man mt-4 iconbox hover:bg-blue-500 rounded p-2 flex gap-2 items-center">
          <FaShoppingBag className="text-gray-500" />
          <h2 className="text-gray-500 font-semibold text-[14px]">
            Travel Agency
          </h2>
        </div>
        <div className="pro_man mt-4 iconbox hover:bg-blue-500 rounded p-2 flex gap-2 items-center">
          <FaRocketchat className="text-gray-500" />
          <h2 className="text-gray-500 font-semibold text-[14px]">
            Chat
          </h2>
        </div>
        <div className="pro_man mt-4 iconbox hover:bg-blue-500 rounded p-2 flex gap-2 items-center">
          <MdEmail className="text-gray-500" />
          <h2 className="text-gray-500 font-semibold text-[14px]">
            Email
          </h2>
        </div>
        <div className="pro_man mt-4 iconbox hover:bg-blue-500 rounded p-2 flex gap-2 items-center">
          <BsCalendar2EventFill className="text-gray-500" />
          <h2 className="text-gray-500 font-semibold text-[14px]">
            Event
          </h2>
        </div>
        <div className="pro_man mt-4 iconbox hover:bg-blue-500 rounded p-2 flex gap-2 items-center">
          <BsFileBarGraphFill className="text-gray-500" />
          <h2 className="text-gray-500 font-semibold text-[14px]">
            Kanban
          </h2>
        </div>
        <div className="pro_man mt-4 iconbox hover:bg-blue-500 rounded p-2 flex gap-2 items-center">
          <FaShareAlt className="text-gray-500" />
          <h2 className="text-gray-500 font-semibold text-[14px]">
            Social
          </h2>
        </div>
        <div className="pro_man mt-4 iconbox hover:bg-blue-500 rounded p-2 flex gap-2 items-center">
          <FaCalendarAlt className="text-gray-500" />
          <h2 className="text-gray-500 font-semibold text-[14px]">
            Calender
          </h2>
        </div>
      </div>
    </div>
  );
};

export default SideMenu;
