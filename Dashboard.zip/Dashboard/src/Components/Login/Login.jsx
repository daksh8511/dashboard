import { TextField } from '@mui/material'
import React from 'react'

const Login = () => {
  return (
    <div>
      <TextField placeholder='Enter Name' label="Name" />
    </div>
  )
}

export default Login